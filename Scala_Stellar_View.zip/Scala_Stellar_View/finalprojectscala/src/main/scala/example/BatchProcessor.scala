import org.apache.spark.sql.SparkSession
import org.apache.log4j.{Level, Logger}

object BatchProcessor {

  def main(args: Array[String]): Unit = {
    // Set Logger Level to ERROR to reduce verbosity
    Logger.getLogger("org").setLevel(Level.ERROR)
    val logger = Logger.getLogger(getClass.getName)

    logger.info("Starting BatchProcessor...")

    val spark = SparkSession.builder
      .appName("BatchProcessor")
      .master("local[*]")
      .getOrCreate()

    // Path to your CSV file
    val csvPath = "data/stellarobjects.csv"

    logger.info(s"Reading CSV file from $csvPath")

    // Read CSV into DataFrame
    val df = spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv(csvPath)

    // Show schema
    df.printSchema()

    // Example Transformation: Select relevant columns
    val selectedDF = df.select("obj_ID", "alpha", "delta", "redshift")

    // Show some data
    selectedDF.show(10)

    // Optionally, write processed data to disk
    selectedDF.write
      .mode("overwrite")
      .parquet("output/batch_processed.parquet")

    logger.info("Batch processing completed.")

    spark.stop()
  }
}
