package com.example

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.log4j.{Level, Logger}

object StreamProcessor {
  
  def main(args: Array[String]): Unit = {
    // Set Logger Level to ERROR to reduce verbosity
    Logger.getLogger("org").setLevel(Level.ERROR)

    val spark = SparkSession.builder
      .appName("StreamProcessor")
      .master("local[*]")
      .getOrCreate()

    import spark.implicits._

    // Path to your CSV streaming directory
    val inputPath = "data/stellarobjects.csv"

    // Define schema to ensure consistency
    val schema = StructType(Array(
      StructField("obj_ID", StringType, true),
      StructField("alpha", DoubleType, true),
      StructField("delta", DoubleType, true),
      StructField("u", DoubleType, true),
      StructField("g", DoubleType, true),
      StructField("r", DoubleType, true),
      StructField("i", DoubleType, true),
      StructField("z", DoubleType, true),
      StructField("run_ID", StringType, true),
      StructField("rerun_ID", StringType, true),
      StructField("cam_col", StringType, true),
      StructField("field_ID", StringType, true),
      StructField("spec_obj_ID", StringType, true),
      StructField("class", StringType, true),
      StructField("redshift", DoubleType, true),
      StructField("plate", StringType, true),
      StructField("MJD", StringType, true),
      StructField("fiber_ID", StringType, true)
    ))

    // Read streaming data
    val df = spark.readStream
      .option("header", "true")
      .schema(schema)
      .csv(csvDir)

    // Example Transformation: Select relevant columns and add timestamp
    val transformedDF = df.select($"obj_ID", $"alpha", $"delta", $"redshift", current_timestamp().as("ingest_time"))

    // Write to console for PoC
    val query = transformedDF.writeStream
      .outputMode("append")
      .format("console")
      .option("truncate", "false")
      .start()

    query.awaitTermination()
  }
}
